const App = () => {
  return <>Shopping Cart</>;
};

export default App;
